package com.firoz.sms.dao;

import com.firoz.sms.model.Course;
import java.util.List;

public interface CourseDAO {
  Long save(Course c);
  Course findById(Long id);
  Course findByName(String name);
  List<Course> findAll();
}
